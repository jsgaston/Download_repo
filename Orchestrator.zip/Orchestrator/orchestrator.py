"""
Kraken Futures Orchestrator
============================
🔄 Bucle automático:
   1. Bot1 abre órdenes  (FuturesBotKraken_4.py)
   2. Bot2 monitorea y cierra cuando alcanza el objetivo (FuturesProfitMonitor.py)
   3. Vuelve al paso 1 indefinidamente

✅ Botones Telegram: Parar Bot | Cerrar Todo | Ver Posiciones | Cerrar posición individual
"""

import time
import sys
from datetime import datetime

try:
    import telegram_notifier as tg
    _TG_AVAILABLE = True
except ImportError:
    _TG_AVAILABLE = False
    print("⚠️  telegram_notifier.py no encontrado — notificaciones Telegram desactivadas")

try:
    from FuturesBotKraken_9 import KrakenFuturesAutoTrader, KrakenFuturesClient as ClientTrader
    from FuturesProfitMonitor_5 import KrakenFuturesProfitMonitor
except ImportError as e:
    print(f"❌ Error importando scripts: {e}")
    print("   Asegúrate de que los tres archivos estén en la misma carpeta.")
    sys.exit(1)


# ╔══════════════════════════════════════════════════════════════╗
# ║              CONFIGURACIÓN DEL ORQUESTADOR                   ║
# ╚══════════════════════════════════════════════════════════════╝

WAIT_IF_NO_TRADES_SEC   = 30    # Espera si no hay señales antes de reintentar
WAIT_BETWEEN_CYCLES_SEC = 200     # Pausa entre el cierre del Bot2 y el inicio del Bot1
MAX_CYCLES              = None  # None = infinito


# ╔══════════════════════════════════════════════════════════════╗
# ║                     ORQUESTADOR                              ║
# ╚══════════════════════════════════════════════════════════════╝

def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n[ORQUESTADOR {ts}] {msg}")


def check_has_open_positions() -> bool:
    try:
        from FuturesProfitMonitor import KrakenFuturesClient as ClientMonitor
        client = ClientMonitor()
        result = client.get_open_positions()
        return len(result.get("openPositions", [])) > 0
    except Exception as e:
        log(f"⚠️  No se pudo verificar posiciones: {e}")
        return False


def run_bot1_until_trades(cycle: int) -> int:
    log("🤖 Iniciando BOT 1 — Buscando señales y abriendo órdenes...")
    try:
        trader = KrakenFuturesAutoTrader(cycle=cycle)
        if _TG_AVAILABLE:
            tg.notify_bot_start(cycle, trader._balance_usd)
        trader.run()
        trades_placed = len(trader.trade_log)
        log(f"✅ BOT 1 terminó — {trades_placed} trade(s) abierto(s).")
        return trades_placed
    except Exception as e:
        log(f"❌ BOT 1 error: {e}")
        if _TG_AVAILABLE:
            tg.notify_error("BOT 1 (run_bot1_until_trades)", str(e), cycle)
        return 0


def run_bot2_until_closed(cycle: int):
    log("💰 Iniciando BOT 2 — Monitoreando posiciones hasta objetivo...")
    try:
        monitor = KrakenFuturesProfitMonitor(cycle=cycle)
        # Los handlers ya se registran en el __init__ del monitor
        monitor.run()
        log("✅ BOT 2 terminó — objetivo alcanzado o monitor detenido.")
    except Exception as e:
        log(f"❌ BOT 2 error: {e}")
        if _TG_AVAILABLE:
            tg.notify_error("BOT 2 (run_bot2_until_closed)", str(e), cycle)


def main():
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║            KRAKEN FUTURES ORCHESTRATOR                       ║
    ║  Bot1 (abrir) → Bot2 (cerrar) → Bot1 → Bot2 → ...           ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    print(f"Ciclos máximos  : {'∞ (infinito)' if MAX_CYCLES is None else MAX_CYCLES}")
    print(f"Espera sin señal: {WAIT_IF_NO_TRADES_SEC}s | Pausa entre ciclos: {WAIT_BETWEEN_CYCLES_SEC}s")
    print("\nPresiona Ctrl+C en cualquier momento para detener.\n")

    # ── Arrancar polling de Telegram ──────────────────────────────
    if _TG_AVAILABLE:
        tg.start_polling()
        tg.notify_orchestrator_start(MAX_CYCLES)

    cycle = 0

    try:
        while MAX_CYCLES is None or cycle < MAX_CYCLES:

            # ── Chequear flag de parada Telegram ──────────────────
            if _TG_AVAILABLE and tg.STOP_FLAG:
                log("⏹️  [TG] Señal de parada recibida vía Telegram — deteniendo orquestador.")
                break

            cycle += 1
            log(f"{'='*50}")
            log(f"🔄 CICLO #{cycle} COMENZANDO")
            log(f"{'='*50}")

            # ── FASE 1: Abrir órdenes ──────────────────────────────
            trades = run_bot1_until_trades(cycle)

            # Volver a chequear flag tras el Bot1 (puede tardar varios minutos)
            if _TG_AVAILABLE and tg.STOP_FLAG:
                log("⏹️  [TG] Señal de parada recibida vía Telegram — deteniendo orquestador.")
                break

            if trades == 0:
                if check_has_open_positions():
                    log("ℹ️  Bot1 no abrió nuevas órdenes, pero hay posiciones previas. Pasando al Bot2...")
                else:
                    log(f"⏳ No hay señales ni posiciones. Reintentando en {WAIT_IF_NO_TRADES_SEC}s...")
                    time.sleep(WAIT_IF_NO_TRADES_SEC)
                    cycle -= 1
                    continue

            # ── FASE 2: Monitorear hasta cerrar ───────────────────
            run_bot2_until_closed(cycle)

            # ── Resumen diario cada 10 ciclos ──────────────────────
            if _TG_AVAILABLE and cycle % 10 == 0:
                tg.notify_daily_summary()

            # ── PAUSA entre ciclos ─────────────────────────────────
            if WAIT_BETWEEN_CYCLES_SEC > 0:
                log(f"⏸️  Pausa de {WAIT_BETWEEN_CYCLES_SEC}s antes del siguiente ciclo...")
                time.sleep(WAIT_BETWEEN_CYCLES_SEC)

    except KeyboardInterrupt:
        log("⏹️  Orquestador detenido por el usuario.")

    finally:
        if _TG_AVAILABLE:
            tg.notify_orchestrator_stopped(cycle)
            tg.notify_daily_summary()
            tg.stop_polling()
        print("\n¡Hasta luego!\n")


if __name__ == "__main__":
    main()
