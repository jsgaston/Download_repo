"""
close_all_now.py
=================
Cierra TODAS las posiciones abiertas en Kraken Futures.
Requiere confirmación escribiendo "y" antes de ejecutar.
"""

import hashlib, hmac, base64, time, urllib.parse
import requests
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

# ── Credenciales ──────────────────────────────────────────────
API_KEY    = "Qh9s+qkIjZXgLTTmSA6IcqgrpbZR/Ep7gqKVlYIiPAx7EC2iSLE5A5Hi"
API_SECRET = "aDe8x9pG+uQ/O2+izP0t6q7joPhPLlcxnTABYdo5tXs9B54k4m4/moLRyTDKVMGjBetcT0n1YTcXmJDQISWjeHLP"

CANCEL_ORDERS = True   # Cancelar SL/TP pendientes al cerrar cada posición


# ── Cliente mínimo ────────────────────────────────────────────

class KrakenFuturesClient:

    BASE_URL = "https://futures.kraken.com"

    def _sign(self, endpoint: str, post_data: str, nonce: str) -> str:
        path   = endpoint.replace("/derivatives", "")
        msg    = (post_data + nonce + path).encode("utf-8")
        sha256 = hashlib.sha256(msg).digest()
        secret = base64.b64decode(API_SECRET)
        sig    = hmac.new(secret, sha256, hashlib.sha512).digest()
        return base64.b64encode(sig).decode()

    def _request(self, method: str, endpoint: str, params: dict = None) -> dict:
        nonce     = str(int(time.time() * 1000))
        post_data = urllib.parse.urlencode(params) if params else ""
        url       = self.BASE_URL + endpoint
        signed_pd = ""

        if method == "GET" and params:
            url = self.BASE_URL + endpoint + "?" + post_data
        elif method == "POST":
            signed_pd = post_data

        headers = {
            "APIKey":  API_KEY,
            "Authent": self._sign(endpoint, signed_pd, nonce),
            "Nonce":   nonce,
        }
        if method == "POST":
            headers["Content-Type"] = "application/x-www-form-urlencoded"
            return requests.post(url, data=post_data, headers=headers, timeout=15).json()
        return requests.get(url, headers=headers, timeout=15).json()

    def get_open_positions(self):
        return self._request("GET", "/derivatives/api/v3/openpositions")

    def get_tickers(self):
        return requests.get(self.BASE_URL + "/derivatives/api/v3/tickers", timeout=15).json()

    def send_order(self, symbol, side, size):
        return self._request("POST", "/derivatives/api/v3/sendorder", {
            "orderType":  "mkt",
            "symbol":     symbol,
            "side":       side,
            "size":       int(size),
            "reduceOnly": "true",
        })

    def cancel_all_orders(self, symbol=None):
        return self._request("POST", "/derivatives/api/v3/cancelallorders",
                             {"symbol": symbol} if symbol else {})


# ── Lógica principal ──────────────────────────────────────────

def get_mark_price(tickers: list, symbol: str) -> float:
    for t in tickers:
        if t["symbol"] == symbol:
            return float(t.get("markPrice") or t.get("last") or 0)
    return 0.0


def close_position(client: KrakenFuturesClient, pos: dict) -> dict:
    side   = pos["side"]
    symbol = pos["symbol"]
    size   = float(pos["size"])
    opp    = "sell" if side == "long" else "buy"
    r      = client.send_order(symbol, opp, size)
    ok     = r.get("result") == "success"
    if ok and CANCEL_ORDERS:
        client.cancel_all_orders(symbol)
    return {**pos, "ok": ok, "response": r}


def main():
    print("""
╔══════════════════════════════════════════════════════════╗
║         CIERRE TOTAL DE POSICIONES — Kraken Futures      ║
╚══════════════════════════════════════════════════════════╝
""")

    client = KrakenFuturesClient()

    # ── Verificar conexión ────────────────────────────────────
    print("🔌 Conectando con Kraken Futures...")
    raw = client.get_open_positions()
    if raw.get("result") != "success":
        print(f"❌ Error de autenticación: {raw.get('error')}")
        return

    positions = raw.get("openPositions", [])

    if not positions:
        print("✅ No hay posiciones abiertas. Nada que cerrar.")
        return

    # ── Obtener precios mark para calcular PnL aproximado ─────
    tickers = client.get_tickers().get("tickers", [])

    print(f"\n📊 POSICIONES ABIERTAS ({len(positions)}):\n")
    total_pnl = 0.0
    enriched  = []
    for p in positions:
        symbol = p["symbol"]
        side   = p["side"]
        size   = float(p["size"])
        entry  = float(p["price"])
        mark   = get_mark_price(tickers, symbol)
        pnl    = ((mark - entry) * size if side == "long" else (entry - mark) * size) if mark > 0 else 0.0
        total_pnl += pnl
        arrow  = "📈" if side == "long" else "📉"
        emoji  = "🟢" if pnl >= 0 else "🔴"
        enriched.append({**p, "mark": mark, "pnl": pnl})
        print(f"  {emoji} {arrow}  {symbol:<20} {side.upper():<6} "
              f"x{int(size):<6} entrada: ${entry:,.4f}  mark: ${mark:,.4f}  PnL: ${pnl:+.4f}")

    pnl_emoji = "🟢" if total_pnl >= 0 else "🔴"
    print(f"\n  {pnl_emoji}  PnL TOTAL ESTIMADO: ${total_pnl:+.4f} USD")

    # ── Confirmación ──────────────────────────────────────────
    print("\n" + "─"*60)
    print("⚠️  Esta acción cerrará TODAS las posiciones a precio de mercado.")
    print("    Los SL/TP pendientes también serán cancelados.")
    print("\n  Escribe  y  y pulsa Enter para confirmar.")
    print("  Escribe cualquier otra cosa (o pulsa Enter) para cancelar.")
    print("─"*60)

    try:
        respuesta = input("\n  > ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print("\n\n⏹  Cancelado.")
        return

    if respuesta != "y":
        print(f"\n⏹  Cancelado (escribiste '{respuesta}'). No se cerró ninguna posición.")
        return

    # ── Ejecución ─────────────────────────────────────────────
    print(f"\n🔒 Cerrando {len(enriched)} posición(es) en paralelo...\n")
    closed = 0
    failed = 0

    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(close_position, client, p): p for p in enriched}
        for f in as_completed(futures):
            res   = f.result()
            emoji = "✅" if res["ok"] else "❌"
            print(f"  {emoji}  {res['symbol']} ({res['side'].upper()}) | "
                  f"PnL: ${res['pnl']:+.4f} | "
                  f"{'Cerrado' if res['ok'] else 'ERROR: ' + str(res['response'].get('error', '?'))}")
            if res["ok"]:
                closed += 1
            else:
                failed += 1

    print(f"\n{'='*60}")
    print(f"  ✅ Cerradas : {closed}")
    if failed:
        print(f"  ❌ Fallidas : {failed}")
    print(f"  💰 PnL total: ${total_pnl:+.4f} USD")
    print(f"  🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
